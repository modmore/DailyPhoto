<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2022 modmore | More for MODX

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'DailyPhoto
--------------

Adds a random Unsplash photo to the MODX3 login screen every day.

After installation:

1. Create an application with Unsplash at https://unsplash.com/oauth/applications
2. Copy/paste the **Access Key** to the `daily_photo.access_key` system setting.
3. Optionally, configure a custom search query with the `daily_photo.query` system setting that fits with your brand.

The image is cached based on the date, so you\'ll start seeing a new one after midnight server time.
',
    'changelog' => 'DailyPhoto 1.0.0-pl
-------------------
Released on 2022-01-31

- First official release for MODX 3.0.0-rc1 and up',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'b7a015d09b5cc9cf130e511cbfe0c8f5',
      'native_key' => 'daily_photo',
      'filename' => 'MODX/Revolution/modNamespace/0785dd270bbe3ada01f737caf138b17c.vehicle',
      'namespace' => 'daily_photo',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60107da4cd5864e7e648467afd26eab5',
      'native_key' => 'daily_photo.access_key',
      'filename' => 'MODX/Revolution/modSystemSetting/845010e5b0c252d3940dd35893b4fbb9.vehicle',
      'namespace' => 'daily_photo',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b7db0d2f70ffcb1fe19e818419cd25e2',
      'native_key' => 'daily_photo.query',
      'filename' => 'MODX/Revolution/modSystemSetting/a497adc3683cdc1bdf749e3c37524599.vehicle',
      'namespace' => 'daily_photo',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '30f5a73dc9c96d1769787d74c9d64350',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/92999222df5ecd7033f66c4fc260ab73.vehicle',
      'namespace' => 'daily_photo',
    ),
  ),
);