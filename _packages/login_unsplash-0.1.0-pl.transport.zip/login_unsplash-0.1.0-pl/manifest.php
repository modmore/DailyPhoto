<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2017 modmore | More for MODX

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Login Unsplash
--------------

Adds a random Unsplash photo to the MODX (2.7+) login screen every day.
',
    'changelog' => '++ Login Unsplash 0.1.0
++ Released on 2014-07-18
++++++++++++++++++++++++++
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e9c1bead0da19c4cdac8c207af41c097',
      'native_key' => 'login_unsplash',
      'filename' => 'modNamespace/d45cdeb4a277f052b00ddbecc7fb7113.vehicle',
      'namespace' => 'login_unsplash',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd24f965dfd67235fd228c31f66800e58',
      'native_key' => 'login_unsplash.application_id',
      'filename' => 'modSystemSetting/f3c0b17ab3ffd4664c08cb77347cb244.vehicle',
      'namespace' => 'login_unsplash',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3a6064c037f68add8b1b0bdf64ceac42',
      'native_key' => NULL,
      'filename' => 'modCategory/e40afcc2e3969ba812119631af2f10c3.vehicle',
      'namespace' => 'login_unsplash',
    ),
  ),
);