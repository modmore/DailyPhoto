<?php

$_lang['login_unsplash'] = 'Login Unsplash';
$_lang['setting_login_unsplash.application_id'] = 'Application Client ID';
$_lang['setting_login_unsplash.application_id_desc'] = 'The Client ID associated with an application as created at https://unsplash.com/oauth/applications.';
$_lang['login_unsplash.attribution'] = 'Photo by [[+author]] on [[+unsplash]]';

