Login Unsplash
--------------

Adds a random Unsplash photo to the MODX (2.7+) login screen every day.
